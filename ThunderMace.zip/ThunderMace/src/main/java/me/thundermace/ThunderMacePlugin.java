package me.thundermace;

import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class ThunderMacePlugin extends JavaPlugin implements Listener {

    // ================= TWEAK THESE =================
    // Cooldowns (milliseconds) - stronger ability = longer cooldown
    private static final long CD_WIND     = 10_000;       // Wind Charge shot (10 seconds)
    private static final long CD_SMASH    = 30_000;       // Thunder Shockwave (30 seconds)
    private static final long CD_LEAP     = 60_000;       // Thunder Leap (1 minute)
    private static final long CD_STORM    = 3_600_000;    // Thunder Storm (1 hour)
    private static final long CD_PROC     = 3_000;        // lightning bonus on normal hits (3 seconds)
    private static final long CD_ULTIMATE = 86_400_000;   // Wrath of Zeus (24 hours)

    private static final double HIT_BONUS_DAMAGE = 6.0;
    private static final double SMASH_RADIUS = 7.0,  SMASH_DAMAGE = 9.0;
    private static final double STORM_RADIUS = 12.0, STORM_DAMAGE = 10.0;

    private static final int    ULT_SECONDS = 10;      // how long the ultimate lasts
    private static final double ULT_RADIUS = 20.0;
    private static final double ULT_TICK_DAMAGE = 7.0; // damage every 0.5s to everything nearby
    private static final double ULT_FINALE_RADIUS = 25.0;
    private static final double ULT_FINALE_DAMAGE = 30.0;

    private static final boolean DROP_ON_DEATH = false; // false = mace vanishes on death (get it again by command)
    // ================================================

    // Set to false if you are NOT using the resource pack (items then look like the normal vanilla ones)
    static final boolean USE_TEXTURES = true;

    private NamespacedKey key;
    private final Map<String, Long> cooldowns = new HashMap<>();
    private CustomWeapons weapons;
    private final Set<UUID> ultActive = new HashSet<>();
    private final Set<UUID> windCharges = new HashSet<>();
    private static final Particle.DustOptions GOLD = new Particle.DustOptions(Color.fromRGB(255, 215, 0), 1.6f);

    @Override
    public void onEnable() {
        key = new NamespacedKey(this, "thunder_mace");
        loadCooldowns();
        getServer().getPluginManager().registerEvents(this, this);
        startAura();
        weapons = new CustomWeapons(this);
        getServer().getPluginManager().registerEvents(weapons, this);
        getLogger().info("ThunderMace enabled!");
    }

    @Override
    public void onDisable() {
        saveCooldowns();
    }

    // ---------- Cooldown saving (so long cooldowns survive restarts) ----------
    private File cdFile() {
        return new File(getDataFolder(), "cooldowns.yml");
    }

    private void loadCooldowns() {
        File f = cdFile();
        if (!f.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        long now = System.currentTimeMillis();
        for (String k : y.getKeys(false)) {
            long until = y.getLong(k);
            if (until > now) cooldowns.put(k.replace('|', ':'), until);
        }
    }

    private void saveCooldowns() {
        try {
            getDataFolder().mkdirs();
            YamlConfiguration y = new YamlConfiguration();
            long now = System.currentTimeMillis();
            for (Map.Entry<String, Long> en : cooldowns.entrySet()) {
                if (en.getValue() > now) y.set(en.getKey().replace(':', '|'), en.getValue());
            }
            y.save(cdFile());
        } catch (IOException ex) {
            getLogger().warning("Could not save cooldowns: " + ex.getMessage());
        }
    }

    // Works on both Spigot and Paper
    void actionBar(Player p, String msg) {
        p.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(msg));
    }

    private String formatTime(long ms) {
        long sec = (ms + 999) / 1000;
        long h = sec / 3600, m = (sec % 3600) / 60, s = sec % 60;
        if (h > 0) return h + "h " + m + "m " + s + "s";
        if (m > 0) return m + "m " + s + "s";
        return s + "s";
    }

    // ---------- Item ----------
    ItemStack createMace() {
        ItemStack mace = new ItemStack(Material.MACE);
        ItemMeta meta = mace.getItemMeta();
        meta.setDisplayName(ChatColor.YELLOW + "" + ChatColor.BOLD + "Storm Breaker");
        meta.setLore(Arrays.asList(
                ChatColor.GRAY + "Every hit calls down lightning.",
                "",
                ChatColor.AQUA + "Right-click: " + ChatColor.WHITE + "Wind Charge " + ChatColor.DARK_GRAY + "(10s)",
                ChatColor.AQUA + "Falling hit: " + ChatColor.WHITE + "Thunder Shockwave " + ChatColor.DARK_GRAY + "(30s)",
                ChatColor.AQUA + "Sneak + Right-click: " + ChatColor.WHITE + "Thunder Leap " + ChatColor.DARK_GRAY + "(1m)",
                ChatColor.AQUA + "Left-click air: " + ChatColor.WHITE + "Thunder Storm " + ChatColor.DARK_GRAY + "(1h)",
                ChatColor.GOLD + "Sneak + Left-click air: " + ChatColor.RED + "WRATH OF ZEUS " + ChatColor.DARK_GRAY + "(24h)",
                "",
                ChatColor.DARK_PURPLE + "Command-only artifact"));
        meta.addEnchant(Enchantment.DENSITY, 5, true);
        meta.addEnchant(Enchantment.BREACH, 4, true);
        meta.addEnchant(Enchantment.WIND_BURST, 3, true);
        meta.addEnchant(Enchantment.UNBREAKING, 10, true);
        meta.addEnchant(Enchantment.MENDING, 1, true);
        meta.setUnbreakable(true);
        if (USE_TEXTURES) meta.setItemModel(new NamespacedKey(this, "thunder_mace"));
        meta.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
        mace.setItemMeta(meta);
        return mace;
    }

    private boolean isThunderMace(ItemStack item) {
        if (item == null || item.getType() != Material.MACE || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(key, PersistentDataType.BYTE);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("weapon")) return weapons.giveCommand(sender, args);
        Player target;
        if (args.length > 0) {
            target = Bukkit.getPlayerExact(args[0]);
            if (target == null) { sender.sendMessage(ChatColor.RED + "Player not found."); return true; }
        } else if (sender instanceof Player p) {
            target = p;
        } else {
            sender.sendMessage("Specify a player.");
            return true;
        }
        ItemStack given = createMace();
        target.getInventory().addItem(given);
        announce(target, given.getItemMeta().getDisplayName());
        return true;
    }

    /** Server-wide announcement when someone is given a weapon. */
    void announce(Player target, String weaponName) {
        Bukkit.broadcastMessage(ChatColor.GOLD + "" + ChatColor.BOLD + "\u26A1 " + ChatColor.YELLOW + target.getName()
                + ChatColor.GOLD + " has obtained " + weaponName + ChatColor.GOLD + "!");
        for (Player pl : Bukkit.getOnlinePlayers()) {
            pl.playSound(pl.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
        }
        target.getWorld().strikeLightningEffect(target.getLocation());
    }

    // ---------- Helpers ----------
    /** Returns true if the ability can be used (and starts the cooldown). */
    boolean tryCooldown(Player p, String ability, long ms, boolean notify) {
        String k = p.getUniqueId() + ":" + ability;
        long now = System.currentTimeMillis();
        Long until = cooldowns.get(k);
        if (until != null && now < until) {
            if (notify) {
                actionBar(p, ChatColor.RED + ability + " ready in " + formatTime(until - now));
            }
            return false;
        }
        cooldowns.put(k, now + ms);
        if (ms >= 60_000) saveCooldowns();
        return true;
    }

    private void bolt(Location loc) {
        World w = loc.getWorld();
        w.strikeLightningEffect(loc); // visual + sound only, no fire/block damage
        w.spawnParticle(Particle.ELECTRIC_SPARK, loc.clone().add(0, 1, 0), 40, 0.5, 1, 0.5, 0.2);
        w.spawnParticle(Particle.END_ROD, loc.clone().add(0, 1, 0), 15, 0.3, 0.8, 0.3, 0.05);
    }

    // ---------- Visual effect helpers ----------
    private void ring(Location c, double r, int points, double y) {
        World w = c.getWorld();
        for (int i = 0; i < points; i++) {
            double a = Math.PI * 2 * i / points;
            Location l = c.clone().add(Math.cos(a) * r, y, Math.sin(a) * r);
            w.spawnParticle(Particle.ELECTRIC_SPARK, l, 1, 0, 0, 0, 0);
            if (i % 2 == 0) w.spawnParticle(Particle.DUST, l, 1, 0, 0, 0, 0, GOLD);
        }
    }

    private void expandingRing(Location center, double maxR, int ticks) {
        final Location c = center.clone();
        new BukkitRunnable() {
            int t = 0;
            @Override
            public void run() {
                t++;
                double r = maxR * t / ticks;
                ring(c, r, Math.max(16, (int) (r * 8)), 0.2);
                c.getWorld().spawnParticle(Particle.CLOUD, c.clone().add(0, 0.3, 0), 6, r / 3, 0.1, r / 3, 0.02);
                if (t >= ticks) cancel();
            }
        }.runTaskTimer(this, 0L, 1L);
    }

    private void beam(Location base, double height) {
        World w = base.getWorld();
        for (double y = 0; y < height; y += 0.5) {
            Location l = base.clone().add(0, y, 0);
            w.spawnParticle(Particle.END_ROD, l, 1, 0.1, 0, 0.1, 0.01);
            if (((int) (y * 2)) % 2 == 0) w.spawnParticle(Particle.ELECTRIC_SPARK, l, 2, 0.3, 0, 0.3, 0.1);
        }
    }

    private void helix(Location c, double radius, double height, double phase) {
        World w = c.getWorld();
        for (int strand = 0; strand < 2; strand++) {
            for (double y = 0; y < height; y += 0.25) {
                double a = phase + y * 2 + strand * Math.PI;
                Location l = c.clone().add(Math.cos(a) * radius, y, Math.sin(a) * radius);
                w.spawnParticle(Particle.ELECTRIC_SPARK, l, 1, 0, 0, 0, 0);
            }
        }
    }

    // Orbiting sparks around anyone holding the mace
    private void startAura() {
        new BukkitRunnable() {
            double phase = 0;
            @Override
            public void run() {
                phase += 0.5;
                for (Player p : Bukkit.getOnlinePlayers()) {
                    if (ultActive.contains(p.getUniqueId()) || !holding(p)) continue;
                    Location c = p.getLocation().add(0, 1, 0);
                    for (int i = 0; i < 2; i++) {
                        double a = phase + i * Math.PI;
                        Location l = c.clone().add(Math.cos(a) * 0.8, Math.sin(phase * 0.5 + i) * 0.6, Math.sin(a) * 0.8);
                        p.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, l, 1, 0, 0, 0, 0);
                    }
                    p.getWorld().spawnParticle(Particle.DUST, p.getLocation().add(0, 1.2, 0), 1, 0.4, 0.5, 0.4, 0, GOLD);
                }
            }
        }.runTaskTimer(this, 0L, 2L);
    }

    private boolean holding(Player p) {
        return isThunderMace(p.getInventory().getItemInMainHand()) && p.hasPermission("thundermace.use");
    }

    // ---------- Normal hit + Smash ----------
    @EventHandler
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        if (!(e.getEntity() instanceof LivingEntity victim)) return;
        if (!holding(p)) return;

        if (tryCooldown(p, "Lightning Strike", CD_PROC, false)) {
            e.setDamage(e.getDamage() + HIT_BONUS_DAMAGE);
            bolt(victim.getLocation());
            Location hitLoc = victim.getLocation().add(0, 1, 0);
            victim.getWorld().spawnParticle(Particle.CRIT, hitLoc, 30, 0.4, 0.5, 0.4, 0.4);
            victim.getWorld().spawnParticle(Particle.FIREWORK, hitLoc, 20, 0.2, 0.3, 0.2, 0.15);
        }

        if (p.getFallDistance() > 1.5f && tryCooldown(p, "Thunder Shockwave", CD_SMASH, false)) {
            Location center = victim.getLocation();
            for (Entity ent : center.getWorld().getNearbyEntities(center, SMASH_RADIUS, SMASH_RADIUS, SMASH_RADIUS)) {
                if (!(ent instanceof LivingEntity le) || ent.equals(p) || ent.equals(victim)) continue;
                bolt(le.getLocation());
                le.damage(SMASH_DAMAGE, p);
                Vector push = le.getLocation().toVector().subtract(center.toVector()).setY(0);
                if (push.lengthSquared() > 0) push.normalize();
                le.setVelocity(push.multiply(1.5).setY(0.8));
            }
            center.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, center, 1);
            expandingRing(center, SMASH_RADIUS, 8);
            center.getWorld().playSound(center, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 2f, 0.7f);
            p.setFallDistance(0);
        }
    }

    // ---------- Active abilities ----------
    @EventHandler
    public void onUse(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Player p = e.getPlayer();
        if (!holding(p)) return;

        Action a = e.getAction();
        boolean right = a == Action.RIGHT_CLICK_AIR || a == Action.RIGHT_CLICK_BLOCK;
        boolean leftAir = a == Action.LEFT_CLICK_AIR;

        if (right && p.isSneaking()) {
            thunderLeap(p);
        } else if (right) {
            windCharge(p);
        } else if (leftAir && p.isSneaking()) {
            wrathOfZeus(p);
        } else if (leftAir) {
            thunderStorm(p);
        }
    }

    private void windCharge(Player p) {
        if (!tryCooldown(p, "Wind Charge", CD_WIND, true)) return;
        Vector dir = p.getEyeLocation().getDirection().normalize().multiply(1.6);
        WindCharge wc = p.launchProjectile(WindCharge.class, dir);
        windCharges.add(wc.getUniqueId());
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_WIND_CHARGE_THROW, 1f, 1f);
        new BukkitRunnable() {
            int t = 0;
            @Override
            public void run() {
                if (wc.isDead() || !wc.isValid() || ++t > 100) { cancel(); windCharges.remove(wc.getUniqueId()); return; }
                Location l = wc.getLocation();
                l.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, l, 4, 0.1, 0.1, 0.1, 0.05);
                l.getWorld().spawnParticle(Particle.CLOUD, l, 2, 0.05, 0.05, 0.05, 0.01);
                l.getWorld().spawnParticle(Particle.DUST, l, 2, 0.1, 0.1, 0.1, 0, GOLD);
            }
        }.runTaskTimer(this, 0L, 1L);
    }

    @EventHandler
    public void onWindHit(ProjectileHitEvent e) {
        if (!windCharges.remove(e.getEntity().getUniqueId())) return;
        Location l = e.getEntity().getLocation();
        l.getWorld().spawnParticle(Particle.GUST_EMITTER_LARGE, l, 1);
        l.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, l, 60, 0.6, 0.6, 0.6, 0.3);
        l.getWorld().spawnParticle(Particle.END_ROD, l, 20, 0.4, 0.4, 0.4, 0.15);
        expandingRing(l, 3, 5);
    }

    private void thunderLeap(Player p) {
        if (!tryCooldown(p, "Thunder Leap", CD_LEAP, true)) return;
        bolt(p.getLocation());
        expandingRing(p.getLocation(), 5, 8);
        p.getWorld().spawnParticle(Particle.GUST_EMITTER_LARGE, p.getLocation(), 1);
        new BukkitRunnable() {
            int t = 0;
            @Override
            public void run() {
                if (!p.isOnline() || ++t > 24) { cancel(); return; }
                Location l = p.getLocation();
                helix(l.clone().add(0, -0.5, 0), 0.9, 2.5, t * 0.6);
                l.getWorld().spawnParticle(Particle.CLOUD, l, 5, 0.3, 0.1, 0.3, 0.02);
            }
        }.runTaskTimer(this, 0L, 1L);
        p.setVelocity(new Vector(0, 2.2, 0));
        p.setFallDistance(0);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 1.5f, 1f);
        actionBar(p, ChatColor.AQUA + "Thunder Leap! Slam down on someone!");
    }

    private void thunderStorm(Player p) {
        if (!tryCooldown(p, "Thunder Storm", CD_STORM, true)) return;
        expandingRing(p.getLocation(), STORM_RADIUS, 14);
        beam(p.getLocation(), 12);
        p.getWorld().spawnParticle(Particle.DUST, p.getLocation().add(0, 1, 0), 60, 1.5, 1, 1.5, 0, GOLD);
        int hit = 0;
        for (Entity ent : p.getNearbyEntities(STORM_RADIUS, STORM_RADIUS, STORM_RADIUS)) {
            if (!(ent instanceof LivingEntity le)) continue;
            bolt(le.getLocation());
            le.damage(STORM_DAMAGE, p);
            le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 2));
            hit++;
        }
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 2f, 1f);
        p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 100, 1));
        actionBar(p, ChatColor.YELLOW + "Thunder Storm hit " + hit + " target(s)!");
    }

    // ---------- ULTIMATE ----------
    private void wrathOfZeus(Player p) {
        if (ultActive.contains(p.getUniqueId())) return;
        if (!tryCooldown(p, "Wrath of Zeus", CD_ULTIMATE, true)) return;

        ultActive.add(p.getUniqueId());
        World w = p.getWorld();
        boolean hadStorm = w.hasStorm();
        boolean hadThunder = w.isThundering();
        w.setStorm(true);
        w.setThundering(true);

        int dur = ULT_SECONDS * 20 + 40;
        p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, dur, 1));
        p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, dur, 2));
        p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, dur, 2));
        p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, dur, 2));
        p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, dur, 4));
        p.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, dur, 0));

        Bukkit.broadcastMessage(ChatColor.GOLD + "" + ChatColor.BOLD + p.getName()
                + ChatColor.RED + " unleashes the WRATH OF ZEUS!");
        p.sendTitle(ChatColor.GOLD + "WRATH OF ZEUS", ChatColor.YELLOW + "Thunder obeys you", 5, 40, 10);
        w.playSound(p.getLocation(), Sound.ENTITY_WITHER_SPAWN, 1.5f, 0.6f);
        expandingRing(p.getLocation(), 15, 12);
        beam(p.getLocation(), 30);
        w.spawnParticle(Particle.FIREWORK, p.getLocation().add(0, 1, 0), 150, 1.5, 1.5, 1.5, 0.3);

        // Continuous spiral aura for the whole ultimate
        new BukkitRunnable() {
            int t = 0;
            double phase = 0;
            @Override
            public void run() {
                if (!p.isOnline() || !ultActive.contains(p.getUniqueId()) || ++t > ULT_SECONDS * 10) { cancel(); return; }
                phase += 0.45;
                Location l = p.getLocation();
                helix(l, 1.4, 3.5, phase);
                helix(l, 2.6, 4.5, -phase);
                l.getWorld().spawnParticle(Particle.DUST, l.clone().add(0, 1, 0), 8, 0.8, 1, 0.8, 0, GOLD);
                if (t % 5 == 0) beam(l, 20);
            }
        }.runTaskTimer(this, 0L, 2L);

        final int totalPulses = ULT_SECONDS * 2; // one pulse every 10 ticks
        final Random rng = new Random();

        new BukkitRunnable() {
            int pulse = 0;

            @Override
            public void run() {
                if (!p.isOnline() || p.isDead()) {
                    end(false);
                    return;
                }
                pulse++;
                Location c = p.getLocation();
                expandingRing(c, ULT_RADIUS, 10);

                // Damage pulse on everything around
                for (Entity ent : p.getNearbyEntities(ULT_RADIUS, ULT_RADIUS, ULT_RADIUS)) {
                    if (!(ent instanceof LivingEntity le)) continue;
                    bolt(le.getLocation());
                    le.damage(ULT_TICK_DAMAGE, p);
                    le.setFireTicks(60);
                }
                // Decorative bolts all around
                for (int i = 0; i < 3; i++) {
                    double ang = rng.nextDouble() * Math.PI * 2;
                    double dist = 4 + rng.nextDouble() * 12;
                    Location l = c.clone().add(Math.cos(ang) * dist, 0, Math.sin(ang) * dist);
                    l.setY(c.getWorld().getHighestBlockYAt(l) + 1);
                    bolt(l);
                }
                c.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, c.clone().add(0, 1, 0), 80, 1.5, 1.5, 1.5, 0.3);
                actionBar(p, ChatColor.GOLD + "WRATH OF ZEUS: "
                        + ChatColor.YELLOW + String.format("%.1f", (totalPulses - pulse) / 2.0) + "s");

                if (pulse >= totalPulses) end(true);
            }

            private void end(boolean finale) {
                cancel();
                ultActive.remove(p.getUniqueId());
                if (!hadStorm) w.setStorm(false);
                if (!hadThunder) w.setThundering(false);
                if (!finale) return;

                // Final cataclysm
                Location c = p.getLocation();
                for (Entity ent : p.getNearbyEntities(ULT_FINALE_RADIUS, ULT_FINALE_RADIUS, ULT_FINALE_RADIUS)) {
                    if (!(ent instanceof LivingEntity le)) continue;
                    bolt(le.getLocation());
                    le.damage(ULT_FINALE_DAMAGE, p);
                    Vector push = le.getLocation().toVector().subtract(c.toVector()).setY(0);
                    if (push.lengthSquared() > 0) push.normalize();
                    le.setVelocity(push.multiply(2.5).setY(1.2));
                }
                c.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, c, 6, 3, 1, 3);
                expandingRing(c, ULT_FINALE_RADIUS, 15);
                beam(c, 40);
                c.getWorld().spawnParticle(Particle.SONIC_BOOM, c.clone().add(0, 1, 0), 1);
                c.getWorld().spawnParticle(Particle.FIREWORK, c.clone().add(0, 1, 0), 300, 4, 2, 4, 0.35);
                c.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, c.clone().add(0, 1, 0), 300, 5, 3, 5, 0.5);
                c.getWorld().playSound(c, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 3f, 0.5f);
                c.getWorld().playSound(c, Sound.ENTITY_GENERIC_EXPLODE, 3f, 0.6f);
                actionBar(p, ChatColor.GOLD + "The storm fades...");
            }
        }.runTaskTimer(this, 0L, 10L);
    }

    // ---------- Safety / command-only ----------
    @EventHandler
    public void onFall(EntityDamageEvent e) {
        if (e.getCause() != EntityDamageEvent.DamageCause.FALL) return;
        if (e.getEntity() instanceof Player p && isThunderMace(p.getInventory().getItemInMainHand())) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        if (DROP_ON_DEATH) return;
        e.getDrops().removeIf(this::isThunderMace);
    }

    // Stop the mace being used in crafting (repair/duplication tricks) or anvils (copying enchants)
    @EventHandler
    public void onCraft(PrepareItemCraftEvent e) {
        for (ItemStack it : e.getInventory().getMatrix()) {
            if (isThunderMace(it)) { e.getInventory().setResult(null); return; }
        }
    }

    @EventHandler
    public void onAnvil(PrepareAnvilEvent e) {
        for (ItemStack it : e.getInventory().getContents()) {
            if (isThunderMace(it)) { e.setResult(null); return; }
        }
    }
}
