package me.thundermace;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * Three extra command-only weapons:
 *  - Inferno Blade   (netherite sword, fire)
 *  - Glacier Cleaver (netherite axe, ice)
 *  - Shadow Scythe   (netherite hoe, shadow / lifesteal)
 * Controls: Right-click = ability 1, Sneak+Right-click = ability 2,
 *           Left-click air = ability 3, Sneak+Left-click air = ULTIMATE.
 */
public class CustomWeapons implements Listener {

    // ================= TWEAK THESE =================
    // Cooldowns in milliseconds
    private static final long CD_A1 = 60_000;        // ability 1: 1 minute
    private static final long CD_A2 = 300_000;       // ability 2: 5 minutes
    private static final long CD_A3 = 3_600_000;     // ability 3: 1 hour
    private static final long CD_ULT = 86_400_000;   // ultimate: 24 hours
    // ================================================

    static final String INFERNO = "inferno", GLACIER = "glacier", SCYTHE = "scythe";

    private final ThunderMacePlugin plugin;
    private final NamespacedKey idKey;

    CustomWeapons(ThunderMacePlugin plugin) {
        this.plugin = plugin;
        this.idKey = new NamespacedKey(plugin, "weapon_id");
    }

    // ---------- Items ----------
    String idOf(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(idKey, PersistentDataType.STRING);
    }

    boolean isCustom(ItemStack item) {
        return idOf(item) != null;
    }

    private ItemStack build(Material m, String id, String model, String name, List<String> lore, Map<Enchantment, Integer> ench) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(lore);
        for (Map.Entry<Enchantment, Integer> en : ench.entrySet()) meta.addEnchant(en.getKey(), en.getValue(), true);
        meta.setUnbreakable(true);
        if (ThunderMacePlugin.USE_TEXTURES) meta.setItemModel(new NamespacedKey(plugin, model));
        meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, id);
        it.setItemMeta(meta);
        return it;
    }

    private List<String> lore(ChatColor c, String tagline, String a1, String a2, String a3, String ult) {
        return Arrays.asList(
                ChatColor.GRAY + tagline, "",
                ChatColor.AQUA + "Right-click: " + ChatColor.WHITE + a1 + ChatColor.DARK_GRAY + " (1m)",
                ChatColor.AQUA + "Sneak + Right-click: " + ChatColor.WHITE + a2 + ChatColor.DARK_GRAY + " (5m)",
                ChatColor.AQUA + "Left-click air: " + ChatColor.WHITE + a3 + ChatColor.DARK_GRAY + " (1h)",
                ChatColor.GOLD + "Sneak + Left-click air: " + c + "" + ChatColor.BOLD + ult + ChatColor.DARK_GRAY + " (24h)",
                "", ChatColor.DARK_PURPLE + "Command-only artifact");
    }

    ItemStack create(String id) {
        switch (id) {
            case INFERNO:
                return build(Material.NETHERITE_SWORD, INFERNO, "inferno_blade",
                        ChatColor.RED + "" + ChatColor.BOLD + "Inferno Blade",
                        lore(ChatColor.RED, "Forged in the heart of the Nether.", "Flame Wave", "Fire Dash", "Meteor Strike", "INFERNO NOVA"),
                        Map.of(Enchantment.SHARPNESS, 10, Enchantment.FIRE_ASPECT, 5, Enchantment.SWEEPING_EDGE, 5,
                                Enchantment.LOOTING, 5, Enchantment.UNBREAKING, 10, Enchantment.MENDING, 1));
            case GLACIER:
                return build(Material.NETHERITE_AXE, GLACIER, "glacier_cleaver",
                        ChatColor.AQUA + "" + ChatColor.BOLD + "Glacier Cleaver",
                        lore(ChatColor.AQUA, "Colder than the end of the world.", "Ice Shards", "Frost Armor", "Blizzard", "ABSOLUTE ZERO"),
                        Map.of(Enchantment.SHARPNESS, 10, Enchantment.EFFICIENCY, 10, Enchantment.UNBREAKING, 10,
                                Enchantment.MENDING, 1, Enchantment.FORTUNE, 5));
            case SCYTHE:
                return build(Material.NETHERITE_HOE, SCYTHE, "shadow_scythe",
                        ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "Shadow Scythe",
                        lore(ChatColor.DARK_PURPLE, "It harvests more than crops.", "Shadow Step", "Soul Drain", "Death Mark", "REAPER'S HARVEST"),
                        Map.of(Enchantment.SHARPNESS, 10, Enchantment.EFFICIENCY, 10, Enchantment.UNBREAKING, 10,
                                Enchantment.MENDING, 1));
            default:
                return null;
        }
    }

    boolean giveCommand(CommandSender sender, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(ChatColor.RED + "Usage: /weapon <stormbreaker|inferno|glacier|scythe> [player]");
            return true;
        }
        String id = args[0].toLowerCase();
        ItemStack item = (id.equals("stormbreaker") || id.equals("mace")) ? plugin.createMace() : create(id);
        if (item == null) {
            sender.sendMessage(ChatColor.RED + "Unknown weapon. Options: stormbreaker, inferno, glacier, scythe");
            return true;
        }
        Player target;
        if (args.length > 1) {
            target = Bukkit.getPlayerExact(args[1]);
            if (target == null) { sender.sendMessage(ChatColor.RED + "Player not found."); return true; }
        } else if (sender instanceof Player pl) {
            target = pl;
        } else {
            sender.sendMessage("Specify a player.");
            return true;
        }
        target.getInventory().addItem(item);
        plugin.announce(target, item.getItemMeta().getDisplayName());
        return true;
    }

    // ---------- Passive on-hit effects ----------
    @EventHandler
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p) || !(e.getEntity() instanceof LivingEntity v)) return;
        String id = idOf(p.getInventory().getItemInMainHand());
        if (id == null || !p.hasPermission("thundermace.use")) return;
        if (!plugin.tryCooldown(p, "Weapon Strike", 3_000, false)) return; // bonus effect every 3s
        Location l = v.getLocation().add(0, 1, 0);
        World w = v.getWorld();
        switch (id) {
            case INFERNO -> {
                e.setDamage(e.getDamage() + 4);
                v.setFireTicks(100);
                w.spawnParticle(Particle.FLAME, l, 30, 0.4, 0.5, 0.4, 0.05);
                w.spawnParticle(Particle.LAVA, l, 8, 0.3, 0.4, 0.3, 0);
            }
            case GLACIER -> {
                e.setDamage(e.getDamage() + 5);
                v.setFreezeTicks(200);
                v.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 1));
                w.spawnParticle(Particle.SNOWFLAKE, l, 40, 0.4, 0.5, 0.4, 0.05);
            }
            case SCYTHE -> {
                e.setDamage(e.getDamage() + 4);
                v.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 60, 1));
                heal(p, 2);
                w.spawnParticle(Particle.SOUL, l, 20, 0.4, 0.5, 0.4, 0.05);
            }
        }
    }

    // ---------- Ability input ----------
    @EventHandler
    public void onUse(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Player p = e.getPlayer();
        String id = idOf(p.getInventory().getItemInMainHand());
        if (id == null || !p.hasPermission("thundermace.use")) return;

        Action a = e.getAction();
        boolean right = a == Action.RIGHT_CLICK_AIR || a == Action.RIGHT_CLICK_BLOCK;
        boolean leftAir = a == Action.LEFT_CLICK_AIR;
        int slot = right ? (p.isSneaking() ? 2 : 1) : leftAir ? (p.isSneaking() ? 4 : 3) : 0;
        if (slot == 0) return;
        if (right) e.setCancelled(true); // no stripping logs / tilling soil

        switch (id) {
            case INFERNO -> inferno(p, slot);
            case GLACIER -> glacier(p, slot);
            case SCYTHE -> scythe(p, slot);
        }
    }

    // =====================================================
    //                     INFERNO BLADE
    // =====================================================
    private void inferno(Player p, int slot) {
        switch (slot) {
            case 1 -> { // Flame Wave
                if (!plugin.tryCooldown(p, "Flame Wave", CD_A1, true)) return;
                for (LivingEntity le : ray(p, 14, 2.0, Particle.FLAME)) {
                    le.damage(10, p);
                    le.setFireTicks(120);
                }
                p.getWorld().playSound(p.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1.5f, 0.7f);
            }
            case 2 -> { // Fire Dash
                if (!plugin.tryCooldown(p, "Fire Dash", CD_A2, true)) return;
                Vector dir = p.getLocation().getDirection().setY(0).normalize().multiply(2.2).setY(0.25);
                p.setVelocity(dir);
                p.setFallDistance(0);
                p.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 100, 0));
                p.getWorld().playSound(p.getLocation(), Sound.ITEM_FIRECHARGE_USE, 1.5f, 0.8f);
                Set<UUID> hit = new HashSet<>();
                new BukkitRunnable() {
                    int t = 0;
                    @Override
                    public void run() {
                        if (!p.isOnline() || ++t > 12) { cancel(); return; }
                        Location l = p.getLocation().add(0, 1, 0);
                        l.getWorld().spawnParticle(Particle.FLAME, l, 25, 0.4, 0.5, 0.4, 0.05);
                        l.getWorld().spawnParticle(Particle.LAVA, l, 3, 0.3, 0.3, 0.3, 0);
                        for (LivingEntity le : near(p, 2.5)) {
                            if (hit.add(le.getUniqueId())) { le.damage(7, p); le.setFireTicks(100); }
                        }
                    }
                }.runTaskTimer(plugin, 0L, 1L);
            }
            case 3 -> { // Meteor Strike
                Block b = p.getTargetBlockExact(35);
                Location tgt = b != null ? b.getLocation().add(0.5, 1, 0.5)
                        : p.getEyeLocation().add(p.getEyeLocation().getDirection().multiply(20));
                if (!plugin.tryCooldown(p, "Meteor Strike", CD_A3, true)) return;
                p.getWorld().playSound(tgt, Sound.ENTITY_BLAZE_SHOOT, 2f, 0.5f);
                new BukkitRunnable() {
                    int t = 0;
                    @Override
                    public void run() {
                        Location m = tgt.clone().add(0, 24 - t * 2.4, 0);
                        World w = m.getWorld();
                        w.spawnParticle(Particle.FLAME, m, 40, 0.6, 0.6, 0.6, 0.05);
                        w.spawnParticle(Particle.LAVA, m, 6, 0.5, 0.5, 0.5, 0);
                        w.spawnParticle(Particle.LARGE_SMOKE, m, 10, 0.5, 0.5, 0.5, 0.02);
                        if (++t > 10) {
                            cancel();
                            w.spawnParticle(Particle.EXPLOSION_EMITTER, tgt, 3, 1.5, 0.5, 1.5, 0);
                            w.spawnParticle(Particle.FLAME, tgt, 200, 3, 1, 3, 0.15);
                            w.playSound(tgt, Sound.ENTITY_GENERIC_EXPLODE, 3f, 0.6f);
                            expRing(tgt, 7, 8, Particle.FLAME);
                            for (Entity en : w.getNearbyEntities(tgt, 6, 6, 6)) {
                                if (!(en instanceof LivingEntity le) || en.equals(p)) continue;
                                le.damage(20, p);
                                le.setFireTicks(160);
                                le.setVelocity(push(le.getLocation(), tgt, 1.5, 0.8));
                            }
                        }
                    }
                }.runTaskTimer(plugin, 0L, 1L);
            }
            case 4 -> { // INFERNO NOVA (ultimate)
                if (!plugin.tryCooldown(p, "Inferno Nova", CD_ULT, true)) return;
                Bukkit.broadcastMessage(ChatColor.RED + "" + ChatColor.BOLD + p.getName() + ChatColor.GOLD + " is charging INFERNO NOVA!");
                p.sendTitle(ChatColor.RED + "INFERNO NOVA", ChatColor.GOLD + "Charging...", 5, 50, 10);
                p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 100, 3));
                p.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 200, 0));
                p.getWorld().playSound(p.getLocation(), Sound.ENTITY_WITHER_SPAWN, 1.5f, 0.5f);
                new BukkitRunnable() {
                    int t = 0;
                    @Override
                    public void run() {
                        if (!p.isOnline() || p.isDead()) { cancel(); return; }
                        t++;
                        Location c = p.getLocation();
                        spiral(c, 1.2 + t * 0.03, 4, t * 0.5, Particle.FLAME);
                        spiral(c, 2.2, 3, -t * 0.5, Particle.SMALL_FLAME);
                        if (t < 60) return;
                        cancel();
                        World w = c.getWorld();
                        column(c, 40, Particle.FLAME);
                        expRing(c, 18, 15, Particle.FLAME);
                        w.spawnParticle(Particle.EXPLOSION_EMITTER, c, 8, 4, 1, 4, 0);
                        w.spawnParticle(Particle.LAVA, c, 150, 6, 2, 6, 0);
                        w.playSound(c, Sound.ENTITY_GENERIC_EXPLODE, 3f, 0.5f);
                        w.playSound(c, Sound.ENTITY_DRAGON_FIREBALL_EXPLODE, 3f, 0.6f);
                        for (Entity en : p.getNearbyEntities(18, 18, 18)) {
                            if (!(en instanceof LivingEntity le)) continue;
                            le.damage(45, p);
                            le.setFireTicks(200);
                            le.setVelocity(push(le.getLocation(), c, 2.5, 1.2));
                        }
                    }
                }.runTaskTimer(plugin, 0L, 1L);
            }
        }
    }

    // =====================================================
    //                    GLACIER CLEAVER
    // =====================================================
    private void glacier(Player p, int slot) {
        switch (slot) {
            case 1 -> { // Ice Shards
                if (!plugin.tryCooldown(p, "Ice Shards", CD_A1, true)) return;
                for (LivingEntity le : ray(p, 14, 2.0, Particle.SNOWFLAKE)) {
                    le.damage(7, p);
                    le.setFreezeTicks(240);
                    le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 80, 2));
                    ice(le.getLocation().add(0, 1, 0), 30);
                }
                p.getWorld().playSound(p.getLocation(), Sound.BLOCK_GLASS_BREAK, 1.5f, 0.6f);
            }
            case 2 -> { // Frost Armor
                if (!plugin.tryCooldown(p, "Frost Armor", CD_A2, true)) return;
                p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 300, 4));
                p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 300, 1));
                for (LivingEntity le : near(p, 5)) {
                    le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 2));
                    le.setFreezeTicks(120);
                }
                expRing(p.getLocation(), 5, 8, Particle.SNOWFLAKE);
                ice(p.getLocation().add(0, 1, 0), 80);
                p.getWorld().playSound(p.getLocation(), Sound.BLOCK_GLASS_PLACE, 1.5f, 0.5f);
            }
            case 3 -> { // Blizzard
                if (!plugin.tryCooldown(p, "Blizzard", CD_A3, true)) return;
                p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_HURT_FREEZE, 2f, 0.6f);
                new BukkitRunnable() {
                    int t = 0;
                    @Override
                    public void run() {
                        if (!p.isOnline() || p.isDead() || ++t > 12) { cancel(); return; }
                        Location c = p.getLocation().add(0, 1, 0);
                        World w = c.getWorld();
                        w.spawnParticle(Particle.SNOWFLAKE, c, 200, 5, 2.5, 5, 0.1);
                        w.spawnParticle(Particle.CLOUD, c, 30, 5, 2, 5, 0.05);
                        expRing(p.getLocation(), 10, 6, Particle.SNOWFLAKE);
                        for (LivingEntity le : near(p, 10)) {
                            le.damage(3, p);
                            le.setFreezeTicks(140);
                            le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 2));
                        }
                        actionBar(p, ChatColor.AQUA + "Blizzard: " + (12 - t) + "s");
                    }
                }.runTaskTimer(plugin, 0L, 20L);
            }
            case 4 -> { // ABSOLUTE ZERO (ultimate)
                if (!plugin.tryCooldown(p, "Absolute Zero", CD_ULT, true)) return;
                Bukkit.broadcastMessage(ChatColor.AQUA + "" + ChatColor.BOLD + p.getName() + ChatColor.WHITE + " unleashes ABSOLUTE ZERO!");
                p.sendTitle(ChatColor.AQUA + "ABSOLUTE ZERO", ChatColor.WHITE + "Everything freezes", 5, 40, 10);
                p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 200, 3));
                p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 200, 4));
                Location c = p.getLocation();
                World w = c.getWorld();
                w.playSound(c, Sound.ENTITY_WITHER_SPAWN, 1.5f, 1.5f);
                w.playSound(c, Sound.BLOCK_GLASS_BREAK, 3f, 0.5f);
                expRing(c, 20, 20, Particle.SNOWFLAKE);
                column(c, 40, Particle.SNOWFLAKE);
                ice(c.clone().add(0, 1, 0), 400);
                w.spawnParticle(Particle.CLOUD, c.clone().add(0, 1, 0), 300, 8, 2, 8, 0.2);
                for (Entity en : p.getNearbyEntities(20, 20, 20)) {
                    if (!(en instanceof LivingEntity le)) continue;
                    le.damage(25, p);
                    le.setFreezeTicks(400);
                    le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 120, 5));
                    le.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 120, 2));
                    le.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, 120, 2));
                    ice(le.getLocation().add(0, 1, 0), 60);
                }
            }
        }
    }

    // =====================================================
    //                    SHADOW SCYTHE
    // =====================================================
    private void scythe(Player p, int slot) {
        switch (slot) {
            case 1 -> { // Shadow Step
                if (!plugin.tryCooldown(p, "Shadow Step", CD_A1, true)) return;
                Location start = p.getLocation();
                Vector dir = start.getDirection().normalize();
                Location dest = start.clone();
                for (int d = 1; d <= 12; d++) {
                    Location t = start.clone().add(dir.clone().multiply(d));
                    if (!t.getBlock().isPassable() || !t.clone().add(0, 1, 0).getBlock().isPassable()) break;
                    dest = t;
                }
                line(start.clone().add(0, 1, 0), dest.clone().add(0, 1, 0), Particle.SOUL);
                start.getWorld().spawnParticle(Particle.SMOKE, start.clone().add(0, 1, 0), 40, 0.4, 0.7, 0.4, 0.05);
                p.teleport(dest);
                p.setFallDistance(0);
                p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 60, 1));
                dest.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, dest.clone().add(0, 1, 0), 40, 0.4, 0.7, 0.4, 0.05);
                dest.getWorld().playSound(dest, Sound.ENTITY_ENDERMAN_TELEPORT, 1.5f, 0.6f);
            }
            case 2 -> { // Soul Drain
                if (!plugin.tryCooldown(p, "Soul Drain", CD_A2, true)) return;
                int healed = 0;
                for (LivingEntity le : near(p, 10)) {
                    le.damage(7, p);
                    le.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 100, 1));
                    line(le.getLocation().add(0, 1, 0), p.getLocation().add(0, 1, 0), Particle.SOUL);
                    if (healed < 10) { heal(p, 2); healed += 2; }
                }
                p.getWorld().playSound(p.getLocation(), Sound.PARTICLE_SOUL_ESCAPE, 2f, 0.7f);
                expRing(p.getLocation(), 10, 10, Particle.SOUL);
            }
            case 3 -> { // Death Mark
                List<LivingEntity> seen = ray(p, 30, 1.5, null);
                if (seen.isEmpty()) { actionBar(p, ChatColor.RED + "No target in sight"); return; }
                if (!plugin.tryCooldown(p, "Death Mark", CD_A3, true)) return;
                LivingEntity target = seen.get(0);
                target.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 100, 0));
                target.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 100, 1));
                p.getWorld().playSound(target.getLocation(), Sound.ENTITY_WITHER_AMBIENT, 2f, 0.5f);
                new BukkitRunnable() {
                    int t = 0;
                    @Override
                    public void run() {
                        if (!target.isValid()) { cancel(); return; }
                        t++;
                        Location above = target.getLocation().add(0, target.getHeight() + 0.6, 0);
                        ring(above, 0.7, 12, Particle.SOUL);
                        if (t < 20) return;
                        cancel();
                        Location l = target.getLocation().add(0, 1, 0);
                        l.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, l, 120, 0.6, 0.9, 0.6, 0.15);
                        l.getWorld().spawnParticle(Particle.SONIC_BOOM, l, 1);
                        l.getWorld().playSound(l, Sound.ENTITY_WITHER_BREAK_BLOCK, 2f, 0.6f);
                        target.damage(32, p);
                        heal(p, 10);
                    }
                }.runTaskTimer(plugin, 0L, 5L);
            }
            case 4 -> { // REAPER'S HARVEST (ultimate)
                if (!plugin.tryCooldown(p, "Reaper's Harvest", CD_ULT, true)) return;
                Bukkit.broadcastMessage(ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + p.getName() + ChatColor.GRAY + " begins the REAPER'S HARVEST...");
                p.sendTitle(ChatColor.DARK_PURPLE + "REAPER'S HARVEST", ChatColor.GRAY + "Souls are mine", 5, 40, 10);
                int dur = 8 * 20 + 20;
                p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, dur, 0));
                p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, dur, 2));
                p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, dur, 1));
                p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, dur, 1));
                p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, dur, 2));
                p.getWorld().playSound(p.getLocation(), Sound.ENTITY_WITHER_SPAWN, 1.5f, 0.4f);
                new BukkitRunnable() {
                    int t = 0;
                    @Override
                    public void run() {
                        if (!p.isOnline() || p.isDead()) { cancel(); return; }
                        t++;
                        Location c = p.getLocation();
                        spiral(c, 1.4, 3.5, t * 0.45, Particle.SOUL);
                        spiral(c, 2.6, 4.5, -t * 0.45, Particle.SOUL_FIRE_FLAME);
                        if (t % 5 == 0) {
                            for (LivingEntity le : near(p, 15)) {
                                le.damage(6, p);
                                le.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 60, 1));
                                line(le.getLocation().add(0, 1, 0), c.clone().add(0, 1, 0), Particle.SOUL);
                                heal(p, 2);
                            }
                            expRing(c, 15, 8, Particle.SOUL);
                        }
                        if (t < 80) return;
                        cancel();
                        World w = c.getWorld();
                        for (LivingEntity le : near(p, 15)) {
                            le.damage(22, p);
                            le.setVelocity(push(le.getLocation(), c, 1.8, 0.9));
                        }
                        p.setHealth(p.getMaxHealth());
                        column(c, 35, Particle.SOUL_FIRE_FLAME);
                        expRing(c, 15, 12, Particle.SOUL_FIRE_FLAME);
                        w.spawnParticle(Particle.SONIC_BOOM, c.clone().add(0, 1, 0), 1);
                        w.spawnParticle(Particle.SOUL, c.clone().add(0, 1, 0), 300, 5, 3, 5, 0.3);
                        w.playSound(c, Sound.ENTITY_WITHER_DEATH, 2f, 0.7f);
                    }
                }.runTaskTimer(plugin, 0L, 2L);
            }
        }
    }

    // ---------- Shared helpers ----------
    private void actionBar(Player p, String msg) { plugin.actionBar(p, msg); }

    private void heal(Player p, double amt) {
        p.setHealth(Math.min(p.getMaxHealth(), p.getHealth() + amt));
    }

    private List<LivingEntity> near(Player p, double r) {
        List<LivingEntity> out = new ArrayList<>();
        for (Entity en : p.getNearbyEntities(r, r, r)) if (en instanceof LivingEntity le) out.add(le);
        return out;
    }

    private Vector push(Location from, Location center, double power, double up) {
        Vector v = from.toVector().subtract(center.toVector()).setY(0);
        if (v.lengthSquared() > 0) v.normalize();
        return v.multiply(power).setY(up);
    }

    /** Casts a line forward, spawning particles; returns entities hit (nearest first). */
    private List<LivingEntity> ray(Player p, double range, double width, Particle part) {
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection().normalize();
        LinkedHashSet<LivingEntity> hit = new LinkedHashSet<>();
        for (double d = 1; d <= range; d += 1) {
            Location l = eye.clone().add(dir.clone().multiply(d));
            if (l.getBlock().getType().isSolid()) break;
            if (part != null) l.getWorld().spawnParticle(part, l, 8, 0.3, 0.3, 0.3, 0.03);
            for (Entity en : l.getWorld().getNearbyEntities(l, width, width, width)) {
                if (en instanceof LivingEntity le && !en.equals(p)) hit.add(le);
            }
        }
        return new ArrayList<>(hit);
    }

    private void line(Location a, Location b, Particle part) {
        Vector v = b.toVector().subtract(a.toVector());
        double len = v.length();
        if (len == 0) return;
        v.normalize();
        for (double d = 0; d < len; d += 0.5) {
            a.getWorld().spawnParticle(part, a.clone().add(v.clone().multiply(d)), 1, 0, 0, 0, 0);
        }
    }

    private void ring(Location c, double r, int points, Particle part) {
        for (int i = 0; i < points; i++) {
            double a = Math.PI * 2 * i / points;
            c.getWorld().spawnParticle(part, c.clone().add(Math.cos(a) * r, 0.2, Math.sin(a) * r), 1, 0, 0, 0, 0);
        }
    }

    private void expRing(Location center, double maxR, int ticks, Particle part) {
        final Location c = center.clone();
        new BukkitRunnable() {
            int t = 0;
            @Override
            public void run() {
                t++;
                double r = maxR * t / ticks;
                ring(c, r, Math.max(16, (int) (r * 8)), part);
                if (t >= ticks) cancel();
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void column(Location base, double height, Particle part) {
        for (double y = 0; y < height; y += 0.5) {
            base.getWorld().spawnParticle(part, base.clone().add(0, y, 0), 2, 0.25, 0, 0.25, 0.02);
        }
    }

    private void spiral(Location c, double radius, double height, double phase, Particle part) {
        for (int strand = 0; strand < 2; strand++) {
            for (double y = 0; y < height; y += 0.3) {
                double a = phase + y * 2 + strand * Math.PI;
                c.getWorld().spawnParticle(part, c.clone().add(Math.cos(a) * radius, y, Math.sin(a) * radius), 1, 0, 0, 0, 0);
            }
        }
    }

    private void ice(Location l, int count) {
        l.getWorld().spawnParticle(Particle.BLOCK, l, count, 0.6, 0.8, 0.6, 0.1, Material.BLUE_ICE.createBlockData());
        l.getWorld().spawnParticle(Particle.SNOWFLAKE, l, count / 2, 0.6, 0.8, 0.6, 0.05);
    }

    // ---------- Command-only protections ----------
    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        e.getDrops().removeIf(this::isCustom);
    }

    @EventHandler
    public void onCraft(PrepareItemCraftEvent e) {
        for (ItemStack it : e.getInventory().getMatrix()) {
            if (isCustom(it)) { e.getInventory().setResult(null); return; }
        }
    }

    @EventHandler
    public void onAnvil(PrepareAnvilEvent e) {
        for (ItemStack it : e.getInventory().getContents()) {
            if (isCustom(it)) { e.setResult(null); return; }
        }
    }
}
